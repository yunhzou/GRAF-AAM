from pathlib import Path
import shutil,json,hashlib,subprocess
S=Path(__file__).resolve().parent;R=Path('/Users/yunhengz/Desktop/AAM Writing');old=S.parent/'current-validation'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['src','native','bench']:
 shutil.copytree(R/name,S/'engine'/name,ignore=shutil.ignore_patterns('__pycache__','*.so','build','*.pyc'),dirs_exist_ok=True)
for name in ['setup.py','pyproject.toml']:shutil.copy2(R/name,S/'engine'/name)
(S/'engine/tests').mkdir(exist_ok=True)
for n in ['test_native.py','test_native_group_ops.py']:shutil.copy2(R/'tests'/n,S/'engine/tests'/n)
# The existing checkpoint verifier assumes a sweep; retain the same verification
# logic while giving the explicit no-sweep configuration its one expected cut.
p=S/'engine/bench/golden_checkpoint_evaluation.py';t=p.read_text();a='cuts = cut_sweep_items(problem.reactant.wbo, config.cut_floor)';assert t.count(a)==1;t=t.replace(a,a+' if config.sweep_cuts else [()]');p.write_text(t)
# Same pinned SLAP adapter, with only the evaluated cut schedule made selectable.
t=(old/'engine/bench/slap_edge_sweep.py').read_text()
t=t.replace('for ordinal,edge in enumerate([None,*edges]):',"for ordinal,edge in enumerate([None,*edges] if getattr(args,'sweep_cuts',True) else [None]):")
t=t.replace("complete=True,cuts=len(edges)+1)","complete=True,cuts=len(edges)+1 if getattr(args,'sweep_cuts',True) else 1)")
(S/'slap_adapter.py').write_text(t)
shutil.copy2(old/'inputs.json',S/'inputs.json')
shutil.copy2(old/'slap-golden/tasks.json',S/'slap-tasks.json')
shutil.copy2(old/'slap-golden/inputs.json',S/'slap-inputs.json')
# Archive existing verdicts for pilot reproducibility checks, never mapper input.
with __import__('gzip').open(R/'reports/current_validation_20260912/golden-direction-records.json.gz','rt') as f:rows=json.load(f)
verdicts={}
for row in rows:
 f=row['files'];v=f.get('evaluation.json',{}).get('reference_recovery')
 if v in ('recovered','not_recovered'):verdicts[f"{row['case']}/{row['seed']}/{row['direction']}"]=v
(S/'prior-cap100-verdicts.json').write_text(json.dumps(verdicts))
manifest=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),caps=[100,2000],seeds=[1,2,3,10],cases=1851,uncut_seed=1,directions=['R_to_P','P_to_R'],iso_tolerance=1.,root_seed=42,threads=1,search_watchdog_seconds=300,verification_watchdog_seconds=300,worker_rss_mib=6144,partition='cpu_short',max_array_concurrency=100,cpus_per_array_task=1,expected_allocated_cpus_per_task=2,source_sha256={str(p.relative_to(S)):digest(p) for p in (S/'engine').rglob('*') if p.is_file()},slap_adapter_sha256=digest(S/'slap_adapter.py'),inputs_sha256=digest(S/'inputs.json'),scope='Paired same-node Golden accuracy and timing. Cap 2000 main; cap 100 ablation. No-sweep one-seed controls at both caps. SLAP uncut and swept binary/weighted bidirectional unions. Search timing includes graph preparation, mapping and output persistence, excludes reference verification. Every search starts fresh; no resumed timing.')
(S/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared',len(manifest['source_sha256']),'source files; commit',manifest['source_commit'])
