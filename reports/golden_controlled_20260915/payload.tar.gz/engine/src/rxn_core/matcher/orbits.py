"""Orbit grouping for WBO graphs."""
from __future__ import annotations

from collections import defaultdict, deque

import networkx as nx

from .primitives import _edge_wbo, _wbo_bucket
from .policy import as_node_match_policy


class _OrbitMap(dict):
    """dict-like orbit map with optional graph-specific WBO buckets."""

    def __init__(self, *args, wbo_buckets=None, zero_bucket=None,
                 wbo_tol=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.wbo_buckets = dict(wbo_buckets or {})
        self.zero_bucket = zero_bucket
        self.wbo_tol = wbo_tol


def _orbit_wbo_bucket(orbits, a, b, w):
    """WBO bucket consistent with an orbit backend when available."""
    if hasattr(orbits, "wbo_buckets"):
        key = (a, b) if a <= b else (b, a)
        if key in orbits.wbo_buckets:
            return orbits.wbo_buckets[key]
        if orbits.zero_bucket is not None:
            return orbits.zero_bucket
    return _wbo_bucket(w)


def _color_refine_orbits(g, iters=20):
    """Iterated color refinement (1-WL / Morgan extended connectivity) on
    an UNLABELED graph. Returns dict node -> int orbit_id such that two
    nodes have the same orbit_id iff they're indistinguishable under
    iterated neighbor-multiset refinement.

    Used to detect symmetric P-atom orbits: bijections that differ only
    by swapping P-atoms in the same orbit produce identical chemistry
    signatures and can be safely collapsed in the cand list.

    For molecules with little symmetry, every atom ends up in its own
    orbit (no collapse). For benzene rings, methyl Hs, B12 carborane,
    etc., symmetric atoms share an orbit and the K-factorial cand
    explosion is avoided.

    Algorithmic correctness: this is the standard 1-WL test used in
    InChI / RDKit canonical SMILES. It's exact for almost all molecular
    graphs and known to fail only on a small class of regular graphs
    (where 2-WL or full automorphism check is needed). For chemistry
    we're safe.
    """
    elements = nx.get_node_attributes(g, 'element')
    # Initial color: just element
    colors = {v: elements.get(v, '') for v in g.nodes()}
    # WBO bucket width: 0.2 so atoms whose WBO differs by ≤0.1 from xtb
    # noise (or geometry distortion at TS) end up in the same orbit.
    # round(x / 0.2) * 0.2 → bucket centers at 0.0, 0.2, 0.4, ...
    def _bucket(w):
        return int(round(w * 5))   # 0.2-wide buckets, integer-keyed
    for _ in range(iters):
        new = {}
        for v in g.nodes():
            nbr = tuple(sorted(
                (colors[w], _bucket(_edge_wbo(g, v, w)))
                for w in g.nodes()
                if w != v
            ))
            new[v] = (colors[v], nbr)
        # Compact to small ints (cheap downstream hashing)
        unique = {c: i for i, c in
                  enumerate(sorted(set(new.values()), key=str))}
        new_int = {v: unique[new[v]] for v in g.nodes()}
        if new_int == colors:
            break
        colors = new_int
    return colors


def _wbo_tolerance_bucket_lookup(g, tolerance):
    """Return a pair->bucket lookup for the complete WBO graph.

    Buckets are formed by greedy tolerance clustering of the WBO values present
    in this graph. This avoids a hard grid boundary, so values such as 1.0 and
    1.1 land in the same bucket when ``tolerance=0.2``.
    """
    if tolerance <= 0:
        raise ValueError("tolerance must be positive")
    nodes = sorted(g.nodes())
    # Zero is structural: it means that no edge subdivision vertex is
    # emitted below.  Never tolerance-cluster a real edge into that class,
    # even when the matching tolerance is as loose as 1.0.
    values = set()
    pair_values = {}
    for i, a in enumerate(nodes):
        for b in nodes[i + 1:]:
            # The graph's edge mask (normally WBO >= graph_floor) defines
            # topology.  The retained full WBO matrix is for scoring only;
            # sub-floor numerical contacts must remain structural non-edges.
            w = (
                round(float(_edge_wbo(g, a, b)), 12)
                if g.has_edge(a, b) else 0.0
            )
            pair_values[(a, b)] = w
            if w > 0.0:
                values.add(w)

    reps = []
    value_to_bucket = {0.0: 0}
    eps = 1e-12
    for value in sorted(values):
        for idx, rep in enumerate(reps):
            if abs(value - rep) <= tolerance + eps:
                value_to_bucket[value] = idx + 1
                break
        else:
            value_to_bucket[value] = len(reps) + 1
            reps.append(value)
    return {
        pair: value_to_bucket[value] if value > 0.0 else 0
        for pair, value in pair_values.items()
    }, 0


def _nauty_colored_wbo_graph(g, wbo_tol=0.2, atom_color_tags=None,
                             node_policy=None):
    try:
        import pynauty
    except ImportError as exc:
        raise RuntimeError(
            "pynauty is required for nauty symmetry operations; install "
            "pynauty or use _color_refine_orbits"
        ) from exc

    atom_color_tags = dict(atom_color_tags or {})
    nodes = sorted(g.nodes())
    atom_index = {node: idx for idx, node in enumerate(nodes)}
    pair_buckets, zero_bucket = _wbo_tolerance_bucket_lookup(g, wbo_tol)
    node_policy = as_node_match_policy(node_policy)

    adjacency = defaultdict(set)
    vertex_colors = defaultdict(set)
    for node, idx in atom_index.items():
        tag = atom_color_tags.get(node)
        vertex_colors[('atom', node_policy.key(g, node), tag)].add(idx)

    next_idx = len(nodes)
    for (a, b), bucket in sorted(pair_buckets.items()):
        if bucket == zero_bucket:
            continue
        edge_idx = next_idx
        next_idx += 1
        ai = atom_index[a]
        bi = atom_index[b]
        adjacency[ai].add(edge_idx)
        adjacency[bi].add(edge_idx)
        adjacency[edge_idx].update((ai, bi))
        vertex_colors[('wbo', bucket)].add(edge_idx)

    adjacency_dict = {
        idx: sorted(adjacency.get(idx, ()))
        for idx in range(next_idx)
    }
    coloring = [
        set(vertices)
        for _, vertices in sorted(vertex_colors.items(), key=lambda item: str(item[0]))
    ]
    nauty_graph = pynauty.Graph(
        next_idx, directed=False,
        adjacency_dict=adjacency_dict,
        vertex_coloring=coloring)
    return nodes, atom_index, nauty_graph, pair_buckets, zero_bucket


def _nauty_orbits(g, wbo_tol=0.2, node_policy=None):
    """Exact automorphism orbits for a tolerance-bucketed WBO graph.

    Returns the same shape as :func:`_color_refine_orbits`: ``dict[node] ->
    orbit_id``.  Atom elements are vertex colors.  WBO edge colors are encoded
    by subdivision vertices colored by WBO bucket; the baseline 0-WBO bucket is
    represented by absence of a subdivision vertex.

    ``pynauty`` does the exact automorphism calculation on that colored graph.
    The WBO tolerance only controls bucket construction; local extension still
    performs its normal active R-pair ``iso_tol`` validity checks.
    """
    nodes, atom_index, nauty_graph, pair_buckets, zero_bucket = (
        _nauty_colored_wbo_graph(g, wbo_tol, node_policy=node_policy))
    import pynauty
    _, _, _, raw_orbits, _ = pynauty.autgrp(nauty_graph)

    atom_orbit_groups = defaultdict(list)
    for node, idx in atom_index.items():
        atom_orbit_groups[raw_orbits[idx]].append(node)
    compact = {}
    for orbit_id, (_, group) in enumerate(
            sorted(atom_orbit_groups.items(), key=lambda item: min(item[1]))):
        for node in group:
            compact[node] = orbit_id
    return _OrbitMap(
        compact, wbo_buckets=pair_buckets,
        zero_bucket=zero_bucket, wbo_tol=wbo_tol)


def _nauty_atom_generators(g, wbo_tol=0.2, atom_color_tags=None,
                           node_policy=None):
    """Atom-level automorphism generators for a colored WBO graph.

    ``atom_color_tags`` refines the atom coloring before nauty is run.  This
    lets callers ask for the subgroup that fixes branch-specific atoms or
    preserves branch-specific target pools, then generate only strict
    automorphism variants for that branch.
    """
    nodes, atom_index, nauty_graph, _pair_buckets, _zero_bucket = (
        _nauty_colored_wbo_graph(
            g, wbo_tol, atom_color_tags=atom_color_tags,
            node_policy=node_policy))
    import pynauty
    generators, _grpsize1, _grpsize2, _raw_orbits, _numorbits = (
        pynauty.autgrp(nauty_graph))
    index_to_node = {idx: node for node, idx in atom_index.items()}
    atom_count = len(nodes)
    out = []
    seen = set()
    for gen in generators:
        perm = {}
        for node, idx in atom_index.items():
            image_idx = int(gen[idx])
            if image_idx >= atom_count:
                raise RuntimeError(
                    "nauty automorphism mapped atom vertex to non-atom vertex")
            perm[int(node)] = int(index_to_node[image_idx])
        key = tuple((node, perm[node]) for node in sorted(perm))
        if key not in seen and any(node != image for node, image in key):
            seen.add(key)
            out.append(perm)
    return tuple(out)


def _atom_tuple_orbit(seed, generators):
    """Unique tuple states reachable by applying atom automorphism generators."""
    seed = tuple(int(x) for x in seed)
    if not generators:
        return (seed,)
    seen = {seed}
    q = deque([seed])
    while q:
        state = q.popleft()
        for gen in generators:
            nxt = tuple(int(gen.get(atom, atom)) for atom in state)
            if nxt in seen:
                continue
            seen.add(nxt)
            q.append(nxt)
    return tuple(sorted(seen))


def _cand_canon_signature(cand, p_orbits):
    """Canonical signature for a cand under unlabeled-g_P orbits.

    Two cands with the same signature differ only by permuting P-atoms
    within their unlabeled orbits — they're spectator-equivalent and
    produce identical chemistry signatures.
    """
    return tuple(sorted((r, p_orbits[p]) for r, p in cand.items()))


def _dedup_cands_by_orbit(cands, p_orbits):
    """Collapse cands that differ only by g_P orbit permutations."""
    if not cands or p_orbits is None or len(cands) == 1:
        return cands
    seen = {}
    for c in cands:
        sig = _cand_canon_signature(c, p_orbits)
        if sig not in seen:
            seen[sig] = c
    return list(seen.values())


def _group_nodes_by_signature(nodes, sig_fn):
    groups = defaultdict(list)
    for node in sorted(nodes):
        groups[sig_fn(node)].append(node)
    return [tuple(vs) for _, vs in sorted(groups.items(), key=lambda kv: str(kv[0]))]
